# ===============================================================================
# PPP批量解算主程序
# ===============================================================================

import argparse
import logging
import os
import shutil
import sys

pyDirName, pyFileName = os.path.split(os.path.abspath(__file__))
sys.path.append(f"{pyDirName}/../")

from tool.gnss_sitelist_io import readSitelist
from tool.gnss_ini_tool import t_iniCfg
from tool.gnss_xml_tool import t_xmlCfg
from tool.gnss_timestran_tool import gnssTime2datetime, datetime2doy, ReplaceTimeWildcard
from tool.gnss_run_tool import execute_multi

# =========================================================================================
class t_run_great_pppflt(object):
    """
    批量运行GREAT的流程都通过这个类控制
    """
    def __init__(self, ini_path, year, beg, end):
        """
        存储GREAT的ini格式配置文件信息的类
        """
        if os.path.exists(ini_path):
            self.ini_path = ini_path
            self.ini_config = t_iniCfg(ini_path)
            self.iBeg = beg
            self.iEnd = end
            self.iYear = year
            logging.info(f"Read the path : {ini_path}")
        else:
            self.ini_path = ""
            logging.error(f"Check your path {ini_path}")
            exit(0)

    def run_cmd_pppflt(self, overwrite_path, overwrite_xml, numberThread):
        """
        主函数与对外接口，通过调用这个函数实现整个流程
        """

        # 处理ini文件
        self.procIniConfig()

        # 处理工程文件夹
        self.procProjectPath(overwrite_path)

        # 处理xml文件
        self.procXmlConfig(overwrite_xml)

        # 运行可执行程序
        self.procBinRunning(numberThread)

    def procBinRunning(self, numThread):
        """
        切换到对应工程文件夹，调用可执行程序，计算结果
        """
        # 按照之前确定的工程文件夹列表循环处理
        ## 按照天循环
        yearBeg,begDoy = datetime2doy(self.beg_time)
        yearEnd,endDoy = datetime2doy(self.end_time)
        if yearBeg != yearEnd:
            logging.error(f"Beg Time Year ({yearBeg}) != End Time Year ({yearEnd})")
            raise Exception
        year = yearBeg
        cmd_list = list()
        for doy in range(begDoy, endDoy + 1):
            yearDoyIdx = f"{year:04d}_{doy:03d}"

            # 获取当天的所有命令
            cmd_list = list()
            for pathIdx in self.process_path:
                if yearDoyIdx not in pathIdx:
                    continue

                proPath = self.process_path[pathIdx]
                logging.info(f"Process at : {proPath}")
                if not os.path.exists(proPath):
                    continue
                os.chdir(proPath)

                # 创建result路径
                resultPath = os.path.join(proPath, "pppflt_result")
                
                if not os.path.exists(resultPath):
                    os.makedirs(resultPath)

                # 获取对应的xml文件
                xmlPath = self.xml_path[pathIdx]
                if not os.path.exists(xmlPath):
                    continue
                    
                # 获取运行命令行参数
                great_cmd = f"{self.great_pppflt} -x {xmlPath} > run_cmd_pppflt_{pathIdx}.cmd_log"
                logging.info(f"Run at {great_cmd}")

                # 如果是单线程
                if numThread == 1:
                    # 运行命令
                    logging.info(f"Running cmd : {great_cmd}")
                    ret = os.system(great_cmd)
                else:
                    cmd_list.append(great_cmd)
                
            # 多线程执行
            if numThread != 1:
                if len(cmd_list) == 0:
                    continue
                execute_multi(cmd_list, numThread)
            
    def procXmlConfig(self, overwrite):
        """
        读取xml模板文件后，根据每天实际的文件名称和路径进行替换和处理，然后将xml文件存储到
        工程路径。
        主要处理如下节点
        - beg
        - end
        - rec
        - input
        """
        # 判断模板文件是否存在
        if not os.path.exists(self.great_pppflt_xml ) or not os.path.isfile(self.great_pppflt_xml ):
            logging.error(f"Check your xml file : {self.great_pppflt_xml }")
        self.xml_config = t_xmlCfg(self.great_pppflt_xml )

        # 根据模式循环创建文件夹
        yearBeg,begDoy = datetime2doy(self.beg_time)
        yearEnd,endDoy = datetime2doy(self.end_time)
        if yearBeg != yearEnd:
            logging.error(f"Beg Time Year ({yearBeg}) != End Time Year ({yearEnd})")
            raise Exception
        year = yearBeg
        self.xml_path = dict()

        for dictIDX in self.site_dict:
            for doy in range(begDoy, endDoy + 1):
                # 没创建工程文件夹，直接跳过
                if f"{year:04d}_{doy:03d}_{dictIDX:03d}" not in self.process_path:
                    continue
                
                onePath = os.path.join(self.process_path[f"{year:04d}_{doy:03d}_{dictIDX:03d}"], f"pppflt_{year:04d}_{doy:03d}_{dictIDX:03d}.xml")
                
                # 将xml文件的路径存储
                self.xml_path[f"{year:04d}_{doy:03d}_{dictIDX:03d}"] = onePath

                # 如果需要覆盖，直接移除
                if overwrite and os.path.exists(onePath):
                    os.system(f"rm -f {onePath}")
                elif False == overwrite and os.path.exists(onePath):
                    continue
                
                # 修改开始和结束时间
                beg_time = gnssTime2datetime(f"{year:04d} {(doy):03d}", "YearDoy")
                end_time = gnssTime2datetime(f"{year:04d} {(doy+self.int_time-1):03d}", "YearDoy")
                begTimeStr = f"{beg_time.year:04d}-{beg_time.month:02d}-{beg_time.day:02d} 00:00:00" 
                endTimeStr = f"{end_time.year:04d}-{end_time.month:02d}-{end_time.day:02d} 23:59:59" 
                self.xml_config.setNode2ValueStr("gen", "beg", begTimeStr)
                self.xml_config.setNode2ValueStr("gen", "end", endTimeStr)

                # 修改测站名称
                self.xml_config.setNode2ValueListChangeLine("gen", "rec", self.site_dict[dictIDX], 10, True)

                # 修改输出文件，主要包括如下几种：
                ## log日志类型和输出路径
                self.xml_config.setNode2AtrrValueStr("outputs", "log", "name", f"ppp")
                self.xml_config.setNode2AtrrValueStr("outputs", "log", "type", f"CONSOLE")
                self.xml_config.setNode2ValueStr("outputs", "ppp", os.path.join(self.project_path,f"{year:04d}_{(doy):03d}/pppflt_result/$(rec)_{year:04d}{(doy):03d}"))
                self.xml_config.setNode2ValueStr("outputs", "flt", os.path.join(self.project_path,f"{year:04d}_{(doy):03d}/pppflt_result/$(rec)_{year:04d}{(doy):03d}.flt"))

                # 修改输入文件，主要包括如下几种：
                ## 观测值文件，目前只考虑一个测站
                rinexo_list = list()
                for one_rinexo in self.site_dict[dictIDX]:
                    rinexo = os.path.join(self.rinexo_path, self.rinexo_name)
                    rinexo = ReplaceTimeWildcard(rinexo, beg_time)
                    rinexo = rinexo.replace('<SITE>', f"{one_rinexo}")
                    rinexo = ReplaceTimeWildcard(rinexo, beg_time)
                    rinexo_list.append(rinexo)
                    logging.info(f"Set rinexo add : {rinexo}")
                self.xml_config.setNode2ValueList("inputs", "rinexo", rinexo_list)

                ## 广播星历文件，可能出现多天的情况
                if False == isinstance(self.rinexn_name,list):
                    rinexn = os.path.join(self.rinexn_path, self.rinexn_name)
                    rinexn = ReplaceTimeWildcard(rinexn, beg_time)
                    self.xml_config.setNode2ValueStr("inputs", "rinexn", rinexn)
                    logging.info(f"Set rinexn as : {rinexn}")
                else:
                    rinexn_list = list()
                    for one_rinexn in self.rinexn_name:
                        rinexn = os.path.join(self.rinexn_path, one_rinexn)
                        rinexn = ReplaceTimeWildcard(rinexn, beg_time)
                        rinexn_list.append(rinexn)
                        logging.info(f"Set rinexn add : {rinexn}")
                    self.xml_config.setNode2ValueList("inputs", "rinexn", rinexn_list)

                ## 精密星历文件，可能出现多天的情况
                if False == isinstance(self.sp3_name,list):
                    sp3 = os.path.join(self.sp3_path, self.sp3_name)
                    sp3 = ReplaceTimeWildcard(sp3, beg_time)
                    self.xml_config.setNode2ValueStr("inputs", "sp3", sp3)
                    logging.info(f"Set sp3 as : {sp3}")
                else:
                    sp3_list = list()
                    for one_sp3 in self.sp3_name:
                        sp3 = os.path.join(self.sp3_path, one_sp3)
                        sp3 = ReplaceTimeWildcard(sp3, beg_time)
                        sp3_list.append(sp3)
                        logging.info(f"Set sp3 add : {sp3}")
                    self.xml_config.setNode2ValueList("inputs", "sp3", sp3_list)

                ## 精密钟差文件，可能出现多天的情况
                if False == isinstance(self.rinexc_name,list):
                    rinexc = os.path.join(self.rinexc_path, self.rinexc_name)
                    rinexc = ReplaceTimeWildcard(rinexc, beg_time)
                    self.xml_config.setNode2ValueStr("inputs", "rinexc", rinexc)
                    logging.info(f"Set rinexc as : {rinexc}")
                else:
                    rinexc_list = list()
                    for one_rinexc in self.rinexc_name:
                        rinexc = os.path.join(self.rinexc_path, one_rinexc)
                        rinexc = ReplaceTimeWildcard(rinexc, beg_time)
                        rinexc_list.append(rinexc)
                        logging.info(f"Set rinexc add : {rinexc}")
                    self.xml_config.setNode2ValueList("inputs", "rinexc", rinexc_list)

                ## 精密偏差文件，可能出现多天的情况
                if False == isinstance(self.bia_name,list):
                    bia = os.path.join(self.bia_path, self.bia_name)
                    bia = ReplaceTimeWildcard(bia, beg_time)
                    self.xml_config.setNode2ValueStr("inputs", "bias", bia)
                    logging.info(f"Set bias as : {bia}")
                else:
                    bia_list = list()
                    for one_bia in self.bia_name:
                        bia = os.path.join(self.bia_path, one_bia)
                        bia = ReplaceTimeWildcard(bia, beg_time)
                        bia_list.append(bia)
                        logging.info(f"Set bia add : {bia}")
                    self.xml_config.setNode2ValueList("inputs", "bias", bia_list)

                ## ifcb文件，可能出现多天的情况
                if False == isinstance(self.ifcb_name,list):
                    ifcb = os.path.join(self.ifcb_path, self.ifcb_name)
                    ifcb = ReplaceTimeWildcard(ifcb, beg_time)
                    self.xml_config.setNode2ValueStr("inputs", "ifcb", ifcb)
                    logging.info(f"Set ifcb as : {ifcb}")
                else:
                    ifcb_list = list()
                    for one_ifcb in self.ifcb_name:
                        ifcb = os.path.join(self.ifcb_path, one_ifcb)
                        ifcb = ReplaceTimeWildcard(ifcb, beg_time)
                        ifcb_list.append(ifcb)
                        logging.info(f"Set ifcb add : {ifcb}")
                    self.xml_config.setNode2ValueList("inputs", "ifcb", ifcb_list)

                # UPD产品文件，可能出现多天的情况
                if False == isinstance(self.upd_name,list):
                    upd = os.path.join(self.upd_path, self.upd_name)
                    upd = ReplaceTimeWildcard(upd, beg_time)
                    self.xml_config.setNode2ValueStr("inputs", "upd", upd)
                    logging.info(f"Set upd as : {upd}")
                else:
                    upd_list = list()
                    for one_upd in self.upd_name:
                        upd = os.path.join(self.upd_path, one_upd)
                        upd = ReplaceTimeWildcard(upd, beg_time)
                        upd_list.append(upd)
                        logging.info(f"Set upd add : {upd}")
                    self.xml_config.setNode2ValueList("inputs", "upd", upd_list)

                ## 系统文件，考虑版本不同可能节点名称有差异
                ## 天线文件
                atx = os.path.join(self.systerm_path, self.systerm_atx)
                atx = ReplaceTimeWildcard(atx, beg_time)
                self.xml_config.setNode2ValueStr("inputs", "atx", atx)
                logging.info(f"Set atx as : {atx}")

                ## 天体星历文件
                de = os.path.join(self.systerm_path, self.systerm_de)
                de = ReplaceTimeWildcard(de, beg_time)
                self.xml_config.setNode2ValueStr("inputs", "de", de)
                logging.info(f"Set de as : {de}")

                ## 潮汐形变文件
                blq = os.path.join(self.systerm_path, self.systerm_blq)
                blq = ReplaceTimeWildcard(blq, beg_time)
                self.xml_config.setNode2ValueStr("inputs", "blq", blq)
                logging.info(f"Set blq as : {blq}")

                ## 地球自转文件
                eop = os.path.join(self.systerm_path, self.systerm_eop)
                eop = ReplaceTimeWildcard(eop, beg_time)
                self.xml_config.setNode2ValueStr("inputs", "eop", eop)
                logging.info(f"Set eop as : {eop}")

                # 将修改后的xml保存
                logging.info(f"Save Xml file to : {onePath}")
                self.xml_config.saveDirXML(onePath, False)

        
        

    def procIniConfig(self):
        """
        读取ini文件后，对ini文件中的信息进行处理和存储
        """
        # great_pppflt section
        ## 开始，结束时间
        begTime = self.ini_config.getValue("great_pppflt","beg_time")
        self.beg_time = gnssTime2datetime(f"{self.iYear:04d} {self.iBeg:03d}", "YearDoy")
        logging.info(f"Beg time is : {begTime}")

        endTime = self.ini_config.getValue("great_pppflt","end_time")
        self.end_time = gnssTime2datetime(f"{self.iYear:04d} {self.iEnd:03d}", "YearDoy")
        logging.info(f"End time is : {endTime}")

        ## 单算例处理弧长
        self.int_time = int(self.ini_config.getValue("great_pppflt","int_time"))
        logging.info(f"int_time is : {self.int_time}")

        ## 测站列表
        self.site_path = self.ini_config.getValue("great_pppflt","site_path")
        self.site_list = readSitelist(self.site_path)
        self.site_dict = dict()
        number = 0

        ## number of thread
        cut_number = int(1)
        for site in self.site_list:
            dictIDX = int(number / cut_number)
            if dictIDX not in self.site_dict:
                self.site_dict[dictIDX] = list()
            self.site_dict[dictIDX].append(site)
            number = number + 1
        logging.info(f"Site Path is : {self.site_path}")

        ## 工程文件夹路径
        self.project_path = self.ini_config.getValue("great_pppflt","project_path")
        logging.info(f"project_path is : {self.project_path}")

        ## 模板xml文件路径
        self.great_pppflt_xml  = self.ini_config.getValue("great_pppflt","great_pppflt_xml")
        logging.info(f"great_pppflt_xml  is : {self.great_pppflt_xml }")

        ## 可执行文件路径
        self.great_pppflt= self.ini_config.getValue("great_pppflt","great_pppflt")
        logging.info(f"great_pppflt is : {self.great_pppflt}")

        # data_pool section
        ## 文件命名格式
        ## sp3 和 bias文件
        self.sp3_name = self.ini_config.getValue("data_pool","sp3_name")
        self.bia_name = self.ini_config.getValue("data_pool","bia_name")
        self.ifcb_name = self.ini_config.getValue("data_pool","ifcb_name")

        logging.info(f"sp3_name is : {self.sp3_name}")
        logging.info(f"bia_name is : {self.bia_name}")
        logging.info(f"ifcb_name is : {self.ifcb_name}")

        # rinexo，rinexc和rinexn文件
        self.rinexo_name = self.ini_config.getValue("data_pool","rinexo_name")
        self.rinexn_name = self.ini_config.getValue("data_pool","rinexn_name")
        self.rinexc_name = self.ini_config.getValue("data_pool","rinexc_name")

        logging.info(f"rinexo_name is : {self.rinexo_name}")
        logging.info(f"rinexn_name is : {self.rinexn_name}")
        logging.info(f"rinexc_name is : {self.rinexc_name}")


        ## 文件存放路径
        self.rinexo_path = self.ini_config.getValue("data_pool","rinexo_path")
        self.rinexn_path = self.ini_config.getValue("data_pool","rinexn_path")
        self.rinexc_path = self.ini_config.getValue("data_pool","rinexc_path")
        self.sp3_path = self.ini_config.getValue("data_pool","sp3_path")
        self.bia_path = self.ini_config.getValue("data_pool","bia_path")
        self.ifcb_path = self.ini_config.getValue("data_pool","ifcb_path")

        logging.info(f"rinexo_path is : {self.rinexo_path}")
        logging.info(f"rinexn_path is : {self.rinexn_path}")
        logging.info(f"rinexc_path is : {self.rinexc_path}")
        logging.info(f"sp3_path is : {self.sp3_path}")
        logging.info(f"bia_path is : {self.bia_path}")
        logging.info(f"ifcb_path is : {self.ifcb_path}")

        ## UPD文件路径
        self.upd_name = self.ini_config.getValue("data_pool","upd_name")
        self.upd_path = self.ini_config.getValue("data_pool","upd_path")
        logging.info(f"upd_name is : {self.upd_name}")
        logging.info(f"upd_path is : {self.upd_path}")

        # 系统文件路径和命名
        self.systerm_path = self.ini_config.getValue("data_pool","systerm_path")
        self.systerm_atx = self.ini_config.getValue("data_pool","systerm_atx")
        self.systerm_de = self.ini_config.getValue("data_pool","systerm_de")
        self.systerm_blq = self.ini_config.getValue("data_pool","systerm_blq")
        self.systerm_eop = self.ini_config.getValue("data_pool","systerm_eop")


    def procProjectPath(self, overwrite):
        """
        根据输入的路径和控制参数创建文件夹
        overwrite:true的时候将原文件夹直接清空
        mode:
            SITE, 测站优先，project/<SITE>/<YYYY_DOY>
            TIME, 时间优先，project/<YYYY_DOY>/<SITE>
        """
        # 是文件夹吗？
        if os.path.isfile(self.project_path):
            raise Exception
            return -1
        
        # 文件夹存在吗？
        if not os.path.exists(self.project_path):
            os.makedirs(self.project_path)

        # 根据模式循环创建文件夹
        year,begDoy = datetime2doy(self.beg_time)
        year,endDoy = datetime2doy(self.end_time)
        self.process_path = dict()
        for doy in range(begDoy, endDoy + 1):
            for dictIDX in self.site_dict:
                onePath = os.path.join(self.project_path, f"{year:04d}_{doy:03d}")

                if os.path.exists(onePath):
                    if overwrite:
                        # 需要清空吗？
                        shutil.rmtree(onePath)
                        self.process_path[f"{year:04d}_{doy:03d}_{dictIDX:03d}"] = onePath
                    else:
                        continue
                else:
                    os.makedirs(onePath)
                    self.process_path[f"{year:04d}_{doy:03d}_{dictIDX:03d}"] = onePath

                # 结果文件
                resultPath = os.path.join(onePath, "pppflt_result")
                if not os.path.exists(resultPath):
                    os.makedirs(resultPath)



if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description ="Starting application")
    parser.add_argument('-ini', type=str, help="ini")   # 结束时间
    parser.add_argument('-year', type=int, help="year") # 结束时间
    parser.add_argument('-beg', type=int, help="beg")   # 结束时间
    parser.add_argument('-end', type=int, help="end")   # 结束时间
    args = parser.parse_args()
    ini = args.ini
    year = args.year
    begDoy = args.beg
    endDoy = args.end

    if ini and len(ini) != 0:
        iniPath = ini
    else:
        year = 2024
        begDoy = 40
        endDoy = 42
        iniPath = r"D:\run_ppp\ini\run_pppflt_test.ini"

    run_cmd_pppflt = t_run_great_pppflt(iniPath, year, begDoy, endDoy)

    logging.info("Begin Running!")
    run_cmd_pppflt.run_cmd_pppflt(True, True, 5)

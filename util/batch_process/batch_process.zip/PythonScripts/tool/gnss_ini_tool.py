# =================================================================
# 该脚本主要用于管理数据池，并对不同程序的数据输入进行支持，因此，在头
# 文件中对特定的数据进行标识和命名格式的约定，后续程序中的所有操作都以约定
# 格式和命名为准。
# =================================================================

import configparser
import os
import logging

# ===================================================================
# ini格式文件如下：
# [section_name] 一个节点
# key_name = "value" 节点中的一个值
# ===================================================================
class t_iniCfg(object):  # meter
    def __init__(self, pathIni):
        """
        存储GREAT的XML格式配置文件信息的类
        """
        if os.path.exists(pathIni):
            self.path = pathIni
            self.config = configparser.ConfigParser()
            self.config.read(pathIni,"utf-8")
            logging.info(f"Read the path : {pathIni}")
        else:
            self.path = ""
            logging.error(f"Check your path {pathIni}")

    def getValue(self, sect_name, key_name):
        """
        获取某个key的value, 如果为空直接抛出异常
        """
        result = ""
        if False == self.config.has_section(sect_name):
            result = ""
        if False == self.config.has_option(sect_name, key_name):
            result = ""
        
        # 判断内容是否为空
        result =  self.config.get(sect_name, key_name)
        if result == "":
            raise Exception
        
        # 判断是否是多个字符
        resultList = result.split("~")
        if len(resultList) == 1:
            return resultList[0]
        else:
            return resultList

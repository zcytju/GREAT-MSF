# =================================================================
# 对XML配置文件的解析与生成
# =================================================================
import os
from pickle import NONE
import xml.etree.ElementTree as ET
import lxml.html as lhtml

# =======================================================
# 宏定义
MY_GLOBAL_TEST = False
NODE_logger = "logger"
NODE_monitor = "monitor"
NODE_email = "email"

# data 节点
NODE_systerm = "great_systerm"
NODE_data_pool = "data_pool"

# download 节点
NODE_rinexo_list = "rinexo_list"
NODE_rinexo_hour = "rinexo_hour"
NODE_rinexo_day = "rinexo_day"

NODE_rinexn_list = "rinexn_list"
NODE_rinexn_hour = "rinexn_hour"
NODE_rinexn_day = "rinexn_day"


# =======================================================


class t_xmlCfg(object):  # meter
    """
    存储GREAT的XML格式配置文件信息的类
    """

    def __init__(self, pathXML):
        if os.path.exists(pathXML):
            self.tree = ET.parse(pathXML)  # 将xml解析为树
            self.root = self.tree.getroot()  # 获取根节点
            self.path = pathXML
        else:
            self.tree = NONE
            self.root = NONE
            self.path = NONE

    def saveDirXML(self, xmlPath, overWrite):
        """
        XML另存为
        """
        if not os.path.exists(os.path.dirname(xmlPath)):
            os.makedirs(os.path.dirname(xmlPath))
        xmlFilePath = os.path.join(xmlPath)

        if os.path.exists(xmlFilePath) and not overWrite:
            return
        else:
            self.tree.write(xmlFilePath, encoding='utf-8')
            self._prettyXML(xmlFilePath)

    def saveXML(self, xmlPath, xmlName, overWrite):
        """
        XML另存为
        """
        if not os.path.exists(xmlPath):
            os.makedirs(xmlPath)
        xmlFilePath = os.path.join(xmlPath, xmlName)

        if os.path.exists(xmlFilePath) and not overWrite:
            return
        else:
            self.tree.write(xmlFilePath, encoding='utf-8')
            self._prettyXML(xmlFilePath)

    def _prettyXML(self, xmlPath):
        """
        美化XML文件
        """
        if not os.path.exists(xmlPath):
            return
        else:
            xml_parse = lhtml.etree.XMLParser(remove_blank_text=True)
            tree = lhtml.etree.parse(open(xmlPath, 'r', encoding='utf8'), xml_parse)
            tree.write(xmlPath, pretty_print=True)

    """
    获取所有同名节点
    """

    def getNodes(self, nodeName):
        nodeNum = 0
        nodeList = list()
        for child in self.root.iter(nodeName):
            nodeNum = nodeNum + 1
            nodeList.append(child)
            if MY_GLOBAL_TEST:
                rank = child.tag
                name = child.attrib
                value = child.text
                print(name, rank)
        return (nodeNum, nodeList)

    def getNode(self, nodeName):
        """
        获取节点
        """
        nodeNum = 0
        nodeList = list()
        for child in self.root.iter(nodeName):
            nodeNum = nodeNum + 1
            nodeList.append(child)
        if nodeNum == 0:
            return (0, NONE)
        else:
            if MY_GLOBAL_TEST:
                rank = nodeList[0].tag
                name = nodeList[0].attrib
                print(name, rank)
            return (1, nodeList[0])

    def getNodeValue(self, nodeName):
        """
        获取节点值
        """
        (number, node) = self.getNode(nodeName)
        value = str(node.text).strip()
        return value

    def setNodeValueStr(self, nodeName, value):
        """
        给节点赋值
        """
        (number, node) = self.getNode(nodeName)
        node.text = " " + str(value) + " "

    def setNode2AtrrValueStr(self, nodeName1, nodeName2, attrName, value):
        """
        给节点的attr变量赋值， nodeName1.nodeName2.attrName = value
        """
        node = self.root.find(nodeName1).find(nodeName2)
        if attrName not in node.attrib:
            node.attrib[attrName] = value
        else:
            node.attrib[attrName] = value

    def setNode2ValueStr(self, nodeName1, nodeName2, value):
        """
        给节点赋值， nodeName1.nodeName2 = value
        """
        node = self.root.find(nodeName1).find(nodeName2)
        node.text = " " + str(value) + " "

    def setNode3ValueStr(self, nodeName1, nodeName2, nodeName3, value):
        """
        给节点赋值， nodeName1.nodeName2.nodeName3 = value
        """
        node = self.root.find(nodeName1).find(nodeName2).find(nodeName3)
        node.text = " " + str(value) + " "

    def setNodeValueList(self, nodeName, valueList):
        """
        给节点赋值，list形式
        """
        (number, node) = self.getNode(nodeName)
        textStr = str("\n")
        for value in valueList:
            textStr = textStr + " " + str(value).strip() + " " + "\n"
        node.text = textStr

    def setNode2ValueList(self, nodeName1, nodeName2, valueList):
        """
        给节点赋值， nodeName1.nodeName2 = value
        """
        node = self.root.find(nodeName1).find(nodeName2)
        textStr = str("\n")
        for value in valueList:
            textStr = textStr + " " + str(value).strip() + " " + "\n"
        node.text = textStr

    def setNode2ValueListChangeLine(self, nodeName1, nodeName2, valueList, changeLineNum, isUpper):
        """
        给节点赋值， nodeName1.nodeName2 = value
        """
        node = self.root.find(nodeName1).find(nodeName2)
        textStr = str("\n")
        number = 0
        for value in valueList:
            if True == isUpper:
                textStr = textStr + " " + str(value).strip().upper() + " "
            else:
                textStr = textStr + " " + str(value).strip().lower() + " "
            number = number + 1
            if number % changeLineNum == 0:
                textStr = textStr + "\n"
        node.text = textStr

    def getNodeValueList(self, nodeName):
        """
        获取节点值, 拆分为List
        """
        (number, node) = self.getNode(nodeName)
        value = str(node.text)
        data = value.split()
        return data